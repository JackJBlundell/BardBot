module.exports = {
    state: "online",
    activities: [
        {
            name: `!control --> speak`,
            type: "PLAYING",
        },
        {
            name: `by Tomato#6966`,
            type: "PLAYING",
        },
    ],
    editInterval: 30_000, 
};