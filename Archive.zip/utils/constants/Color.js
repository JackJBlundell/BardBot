module.exports = {
    Main: "#fb32cd",
    Red: "#ff0000"
}